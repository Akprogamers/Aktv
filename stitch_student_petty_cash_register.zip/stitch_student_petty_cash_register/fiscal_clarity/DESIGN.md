---
name: Fiscal Clarity
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf8'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e2e1ed'
  on-surface: '#191b23'
  on-surface-variant: '#434654'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c5d7'
  surface-tint: '#1353d8'
  primary: '#003fb1'
  on-primary: '#ffffff'
  primary-container: '#1a56db'
  on-primary-container: '#d4dcff'
  inverse-primary: '#b5c4ff'
  secondary: '#585f6c'
  on-secondary: '#ffffff'
  secondary-container: '#dce2f3'
  on-secondary-container: '#5e6572'
  tertiary: '#852b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#ad3b00'
  on-tertiary-container: '#ffd4c5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00174d'
  on-primary-fixed-variant: '#003dab'
  secondary-fixed: '#dce2f3'
  secondary-fixed-dim: '#c0c7d6'
  on-secondary-fixed: '#151c27'
  on-secondary-fixed-variant: '#404754'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#802a00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e2e1ed'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  padding-card: 20px
---

## Brand & Style

The design system is anchored in the principles of **Corporate Modernism**, prioritizing utility, transparency, and trust. Designed for students managing shared or personal petty cash, the UI evokes a sense of responsibility and methodical organization. 

The aesthetic is clean and functional, utilizing ample whitespace to reduce cognitive load during financial data entry. By avoiding decorative flourishes, the system ensures that the user's focus remains entirely on the accuracy of the ledger. The emotional response is one of "managed control"—the user should feel that their finances are structured, secure, and easy to audit at a glance.

## Colors

The palette is built on a foundation of "Trust Blue" to establish institutional credibility. 

- **Primary:** A deep, authoritative blue used for primary actions and brand presence.
- **Surface & Background:** Multiple shades of soft grey (`#F9FAFB` to `#E5E7EB`) differentiate the workspace from the container, creating a subtle hierarchical depth without using heavy lines.
- **Semantic Colors:** Critical for a ledger, these are used strictly for financial status. 
    - **Income (Green):** Used for positive deltas and "Add" actions.
    - **Expense (Red):** Used for negative deltas and "Delete/Warning" actions.
- **Typography:** Uses a high-contrast near-black (`#111827`) for maximum legibility on light backgrounds.

## Typography

This design system utilizes **Inter** for its exceptional legibility in data-heavy environments. 

- **Hierarchy:** Headers use tighter letter spacing and heavier weights to anchor sections.
- **Data Tables:** Numerical values should ideally use a tabular-lining feature or a secondary monospaced font like **JetBrains Mono** for financial figures to ensure columns of numbers align perfectly for easier comparison.
- **Labels:** Small, uppercase labels with increased tracking are used for table headers and form field descriptions to distinguish meta-data from user-generated content.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop to ensure financial tables don't become excessively wide and difficult to scan horizontally.

- **Grid:** A 12-column grid with a 24px gutter.
- **Rhythm:** An 8px linear scale (using a 4px base unit) governs all padding and margins.
- **Alignment:** Financial figures in tables are always right-aligned to allow for decimal alignment. Text descriptions are left-aligned. 
- **Mobile Adaption:** On mobile devices, the 12-column grid collapses to a single column. Horizontal tables should be wrapped in a scrollable container or transformed into stacked card lists to maintain readability.

## Elevation & Depth

This design system employs **Tonal Layers** supplemented by **Ambient Shadows** to create a structured hierarchy.

- **Level 0 (Background):** Soft grey (`#F9FAFB`) defines the canvas.
- **Level 1 (Cards/Tables):** White surfaces with a very subtle 1px border (`#E5E7EB`) and a soft, diffused shadow (Y: 2px, Blur: 4px, Opacity: 5%).
- **Level 2 (Modals/Popovers):** Higher contrast shadows (Y: 10px, Blur: 15px, Opacity: 10%) to draw immediate attention to data entry tasks.
- **Depth Cues:** Interactive elements like buttons use a subtle inner shadow on click to provide tactile feedback without veering into full skeuomorphism.

## Shapes

The shape language is **Soft**, utilizing a 4px (0.25rem) base radius.

- **Small Components:** Checkboxes and small buttons use a 4px radius.
- **Large Components:** Summary cards and data tables use an 8px (0.5rem) radius.
- **Inputs:** Text fields use the standard 4px radius to maintain a professional, slightly architectural look.

This subtle rounding balances the "seriousness" of a financial app with modern accessibility, avoiding the sharpness of a strictly utilitarian tool while remaining more professional than a "bubbly" consumer app.

## Components

### Data Tables
Tables are the core of the system. Use high-contrast headers with a light grey background. Implement zebra-striping (alternating row colors) using a very faint grey to guide the eye across wide rows. Hover states on rows should be distinct.

### Summary Cards
Large, bold cards placed at the top of the dashboard. They display the "Current Balance," "Total Income," and "Total Expenses." Use the Primary color for the main balance and semantic colors (Green/Red) for the income/expense summaries.

### Input Forms
Fields must have clear labels and persistent placeholder text. The active/focus state must use the Primary Blue as a 2px outer glow to ensure the user knows exactly where they are typing.

### Chips & Status
Small, rounded indicators used within tables to categorize transactions (e.g., "Food," "Supplies," "Travel"). These use a low-saturation background with a high-saturation text color of the same hue.

### Buttons
- **Primary:** Solid Primary Blue with white text.
- **Secondary:** White background with Primary Blue border and text.
- **Tertiary:** Ghost style, used for "Cancel" or "Go Back" actions to minimize visual noise.